package com.example.tictactoeg2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int player1Points;
    private int player2Points;

    private TextView textViewPlayer1;
    private TextView textViewPlayer2;
    private TextView textViewTurn;
    private Boolean win = false;
    private String winner;

    // 0 = yellow (player1), 1 = red (player2)

    int activePlayer = 0; // player 1 is active player, means player 1 start the game firt

    boolean gameIsActive = true; // the game is running now, the game already start

    // 2 means unplayed

    int[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2};

    int[][] winningPositions = {{0,1,2}, {3,4,5}, {6,7,8}, {0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}};
    // which cell is the winning positions

    // paste here
    // what happen when the user click on the picture, picture in the 9 cell
    public void dropIn(View view) {

        textViewTurn.setText("O's turn");
        ImageView counter = (ImageView) view; // keep track which picture click by the user

        int tappedCounter = Integer.parseInt(counter.getTag().toString());
        // get the tag value for the picture click by the user, convert to string then convert to int
        // "0", "1",..... "8"

        // the cells is still empty, 3 cells and the game status is active

        if (gameState[tappedCounter] == 2 && gameIsActive) {

            gameState[tappedCounter] = activePlayer; // set active  player, player 1 start the game first

            counter.setTranslationY(-1000f); //  run animation effect

            if (activePlayer == 0) { //  if player 1 turn now

                textViewTurn.setText("X's turn");

                counter.setImageResource(R.drawable.circle); // get the yellow circle from res folder

                activePlayer = 1; // pass the turn to player 1

            } else { //  player 2 turn now

                textViewTurn.setText("O's turn");

                counter.setImageResource(R.drawable.cross); //  get the red circle from red folder

                activePlayer = 0; //  pass the turn to player 1 again

            }

            // run animations effects
            counter.animate().translationYBy(1000f).rotation(360).setDuration(300);

            // use for loops to find the winners, the winner can be p1 or p2
            // check the 2D arrays value of the winning positions
            // check all cells selected by the player, match or not match with the winning positions 2D array
            for (int[] winningPosition : winningPositions) {

                if (gameState[winningPosition[0]] == gameState[winningPosition[1]] &&
                        gameState[winningPosition[1]] == gameState[winningPosition[2]] &&
                        gameState[winningPosition[0]] != 2) {

                    win = true;

                    if (gameState[winningPosition[0]] == 0) {

                        player1Points++;
                        PointsX();

                        winner = "O"; // if winning positions is mark by player 1 (O)
                    } else {

                        player2Points++;
                        PointsX();

                        winner = "X"; // if winning positions is mark by player 2 (X)
                    }
                }
            }
                    // Someone has won!

                    if (win){


                    gameIsActive = false; // do not allow the player to play anymore

                    textViewTurn.setText("");

                    // get the label or textview components from res and layout folder, xml file
                    TextView winnerMessage = (TextView) findViewById(R.id.winnerMessage);

                    winnerMessage.setText(winner + " has won!"); // set the value to be display

                        textViewTurn.setText("GAME OVER");

                    // get the linear layout manager from res and layout folder, xml file
                    LinearLayout layout = (LinearLayout)findViewById(R.id.playAgainLayout);

                    layout.setVisibility(View.VISIBLE); // turn it become visible, to display all the components
                    // winner text view and play again buttons

                } else {
                    // ELSE there is no winners or losers
                    // both are equals, and all the 9 cells is filled or click by the player

                    boolean gameIsOver = true; // game is over

                    for (int counterState : gameState) {

                        if (counterState == 2) gameIsOver = false; //  update the status, you cannot click on
                                                                    // the cells anymore, 9 cells

                    }

                    if (gameIsOver) {
                        // get the label or textview from res and layout folder, xml file

                        TextView winnerMessage = (TextView) findViewById(R.id.winnerMessage);

                        winnerMessage.setText("It's a draw"); // set the value to be display

                        textViewTurn.setText("GAME OVER");

                        // get the linear layout from the res and layout folder, xml file

                        // get the linear layout from the res and layout folder, xml file
                        LinearLayout layout = (LinearLayout)findViewById(R.id.playAgainLayout);

                        layout.setVisibility(View.VISIBLE); // make it become visible, to display all components
                        // play again button and textview

                    }

                }

            }
        }



    private void PointsX() {
        textViewPlayer1.setText("O: " + player1Points);
        textViewPlayer2.setText("X: " + player2Points);
    }

    // paste here
    // what happen when the user click play again button
    public void playAgain(View view) {

        win = false;

        textViewTurn.setText("O's turn");

        gameIsActive = true; //  change the game status to active, the game already start

        LinearLayout layout = (LinearLayout)findViewById(R.id.playAgainLayout);

        layout.setVisibility(View.INVISIBLE); // get the linear layout and make it become invisible

        activePlayer = 0; // player 1 start first

        for (int i = 0; i < gameState.length; i++) {

            gameState[i] = 2; // use for loop set the game state value to 2. for 9 cells

        }

        GridLayout gridLayout = (GridLayout)findViewById(R.id.gridLayout); // get the gird layout manager

        // use for loop to set the picture in the cells, yellow or red circles
        for (int i = 0; i< gridLayout.getChildCount(); i++) {

            ((ImageView) gridLayout.getChildAt(i)).setImageResource(0);

        }

    }

    public void reset(View view){

        win = false;

        gameIsActive = true; //  change the game status to active, the game already start

        textViewTurn.setText("O's turn");

        LinearLayout layout = (LinearLayout)findViewById(R.id.playAgainLayout);

        layout.setVisibility(View.INVISIBLE); // get the linear layout and make it become invisible

        activePlayer = 0; // player 1 start first

        for (int i = 0; i < gameState.length; i++) {

            gameState[i] = 2; // use for loop set the game state value to 2. for 9 cells

        }

        GridLayout gridLayout = (GridLayout)findViewById(R.id.gridLayout); // get the gird layout manager

        // use for loop to set the picture in the cells, yellow or red circles
        for (int i = 0; i< gridLayout.getChildCount(); i++) {



            ((ImageView) gridLayout.getChildAt(i)).setImageResource(0);



        }
        // both player 1 (circle) and player 2 (cross) points will be reset to 0
        player1Points = 0;
        player2Points = 0;

        PointsX();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewPlayer1 = findViewById(R.id.text_view_p1);
        textViewPlayer2 = findViewById(R.id.text_view_p2);

        textViewTurn = findViewById(R.id.text_view_turn);



    }
}
